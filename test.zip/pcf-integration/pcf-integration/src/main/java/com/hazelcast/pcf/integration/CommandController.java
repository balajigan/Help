package com.hazelcast.pcf.integration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import com.hazelcast.pcf.integration.model.Order;

@RestController
public class CommandController {

    @Autowired
    HazelcastInstance hazelcastClient;

    @RequestMapping("/put")
    public String put(@RequestParam(value = "orderId") String orderId, @RequestBody Order orderDtls) {
        IMap<String, Order> map = hazelcastClient.getMap("map");
        map.put(orderId, orderDtls);
        return "success";
    }

    @RequestMapping("/get")
    public Order get(@RequestParam(value = "orderId") String orderId) {
        IMap<String, Order> map = hazelcastClient.getMap("map");
        Order value = map.get(orderId);
        return value;
    }

    @RequestMapping("/remove")
    public String remove(@RequestParam(value = "key") String key) {
        IMap<String, Order> map = hazelcastClient.getMap("map");
        map.remove(key);
        return "Data delted successfully";
    }

    @RequestMapping("/size")
    public CommandResponse size() {
        IMap<String, String> map = hazelcastClient.getMap("map");
        int size = map.size();
        return new CommandResponse(Integer.toString(size));
    }

    @RequestMapping("/populate")
    public CommandResponse populate() {
        IMap<String, String> map = hazelcastClient.getMap("map");
        for (int i = 0; i < 1000; i++) {
            String s = Integer.toString(i);
            map.put(s, s);
        }
        return new CommandResponse("1000 entry inserted to the map");
    }

    @RequestMapping("/clear")
    public CommandResponse clear() {
        IMap<String, String> map = hazelcastClient.getMap("map");
        map.clear();
        return new CommandResponse("Map cleared");
    }

	/**
	 * To take a CSV file as input convert it to JSON format and save it to
	 * Hazelcast
	 */
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, value = "/hazelcast/upload")
	public String singleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
		if (file.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "Upload a file");
			return "redirect:uploadStatus";
		}
		try {
			byte[] bytes = file.getBytes();
			Path path = Paths.get(file.getOriginalFilename());
			Files.write(path, bytes);
			String inputFileName = file.getOriginalFilename();
			String tableName;
			if (inputFileName.contains("_")) {
				tableName = inputFileName.substring(0, inputFileName.lastIndexOf("_")).toLowerCase();
			} else {
				tableName = inputFileName.substring(0, inputFileName.lastIndexOf(".csv")).toLowerCase();
			}
			File input = new File(file.getOriginalFilename());
			CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
			CsvMapper csvMapper = new CsvMapper();
			MappingIterator<Map<?, ?>> mappingIterator = null;
			mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(input);

			List<Map<?, ?>> data = mappingIterator.readAll();
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

			Properties prop = new Properties();
			InputStream is = this.getClass().getResourceAsStream("/application.properties");
			prop.load(is);
			System.out.println(prop.getProperty(tableName));

			IMap<String, String> mapMasters = hazelcastClient.getMap(tableName + "_map");
			// PUT the data into the map
			int index;
			for (index = 0; index < data.size(); index++) {
				String jsonStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data.get(index));
				mapMasters.put((String) data.get(index).get(prop.getProperty(tableName)), jsonStr);

			}

			redirectAttributes.addFlashAttribute("message", "successfully uploaded.." + tableName + "_map");

		} catch (IOException e) {
			e.printStackTrace();
		}
		return ("SUCCESS");
	}

	/**
	 * To get data from Hazelcast.
	 */
	@RequestMapping("/hazelcast/get")
	public String getHazlecast(@RequestParam(value = "tableName") String tableName,
			@RequestParam(value = "key") String key) {
		IMap<String, String> map = hazelcastClient.getMap(tableName);
		return map.get(key);
	}

	/**
	 * To take data request body as input convert it to JSON format and save it
	 * to Hazelcast
	 */
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, value = "/hazelcast/rawupload")
	public String uploadTestData(@RequestBody String inputData, @RequestHeader(value = "file") String fileName) {

		String returnStatus = "SUCCESS";
		String processedInput = inputData.replace("%2C", ",").replace("%0D%0A", "\n").replace("=", "");
		System.out.println("Processed Input : " + processedInput);
		try {
			byte[] bytes = processedInput.getBytes();
			Path path = Paths.get(fileName);
			Files.write(path, bytes);

			String tableName;
			if (fileName.contains("_")) {
				tableName = fileName.substring(0, fileName.lastIndexOf("_")).toLowerCase();
			} else {
				tableName = fileName.substring(0, fileName.lastIndexOf(".csv")).toLowerCase();
			}
			File input = new File(fileName);

			CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
			CsvMapper csvMapper = new CsvMapper();
			MappingIterator<Map<?, ?>> mappingIterator = null;
			mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(input);

			List<Map<?, ?>> data = mappingIterator.readAll();
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

			Properties prop = new Properties();
			InputStream is = this.getClass().getResourceAsStream("/application.properties");
			prop.load(is);

			IMap<String, String> mapMasters = hazelcastClient.getMap("ordersMap");

			// PUT the data into the map

			for (int index = 0; index < data.size(); index++) {
				String jsonStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data.get(index));
				mapMasters.put((String) data.get(index).get(prop.getProperty(tableName)), jsonStr);
			}

		} catch (IOException e) {
			e.printStackTrace();
			returnStatus = "FAILURE";
		}

		return (returnStatus);
	}

}
