
package com.hazelcast.pcf.integration.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"MTRL_ID",
"MTRL_ORDR_QTY",
"ORDR_MTRL_UOM_CDV"
})
public class Mtrl implements Serializable
{

@JsonProperty("MTRL_ID")
private String mTRLID;
@JsonProperty("MTRL_ORDR_QTY")
private Integer mTRLORDRQTY;
@JsonProperty("ORDR_MTRL_UOM_CDV")
private String oRDRMTRLUOMCDV;
private final static long serialVersionUID = 5370093375775630076L;

@JsonProperty("MTRL_ID")
public String getMTRLID() {
return mTRLID;
}

@JsonProperty("MTRL_ID")
public void setMTRLID(String mTRLID) {
this.mTRLID = mTRLID;
}

@JsonProperty("MTRL_ORDR_QTY")
public Integer getMTRLORDRQTY() {
return mTRLORDRQTY;
}

@JsonProperty("MTRL_ORDR_QTY")
public void setMTRLORDRQTY(Integer mTRLORDRQTY) {
this.mTRLORDRQTY = mTRLORDRQTY;
}

@JsonProperty("ORDR_MTRL_UOM_CDV")
public String getORDRMTRLUOMCDV() {
return oRDRMTRLUOMCDV;
}

@JsonProperty("ORDR_MTRL_UOM_CDV")
public void setORDRMTRLUOMCDV(String oRDRMTRLUOMCDV) {
this.oRDRMTRLUOMCDV = oRDRMTRLUOMCDV;
}

@Override
public String toString() {
	return "Mtrl [mTRLID=" + mTRLID + ", mTRLORDRQTY=" + mTRLORDRQTY + ", oRDRMTRLUOMCDV=" + oRDRMTRLUOMCDV + "]";
}

}

