package com.hazelcast.pcf.integration.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ORDR_ID",
"ORDR_SRC",
"ORDR_DC",
"MRKT",
"ORDR_DT",
"ORDR_STS",
"SOLD_TO_CUST_ID",
"mtrl"
})
public class Order implements Serializable
{

@JsonProperty("ORDR_ID")
private String oRDRID;
@JsonProperty("ORDR_SRC")
private String oRDRSRC;
@JsonProperty("ORDR_DC")
private String oRDRDC;
@JsonProperty("MRKT")
private String mRKT;
@JsonProperty("ORDR_DT")
private String oRDRDT;
@JsonProperty("ORDR_STS")
private String oRDRSTS;
@JsonProperty("SOLD_TO_CUST_ID")
private String sOLDTOCUSTID;
@JsonProperty("mtrl")
private List<Mtrl> mtrl = null;
private final static long serialVersionUID = 2458015761768814282L;

@JsonProperty("ORDR_ID")
public String getORDRID() {
return oRDRID;
}

@JsonProperty("ORDR_ID")
public void setORDRID(String oRDRID) {
this.oRDRID = oRDRID;
}

@JsonProperty("ORDR_SRC")
public String getORDRSRC() {
return oRDRSRC;
}

@JsonProperty("ORDR_SRC")
public void setORDRSRC(String oRDRSRC) {
this.oRDRSRC = oRDRSRC;
}

@JsonProperty("ORDR_DC")
public String getORDRDC() {
return oRDRDC;
}

@JsonProperty("ORDR_DC")
public void setORDRDC(String oRDRDC) {
this.oRDRDC = oRDRDC;
}

@JsonProperty("MRKT")
public String getMRKT() {
return mRKT;
}

@JsonProperty("MRKT")
public void setMRKT(String mRKT) {
this.mRKT = mRKT;
}

@JsonProperty("ORDR_DT")
public String getORDRDT() {
return oRDRDT;
}

@JsonProperty("ORDR_DT")
public void setORDRDT(String oRDRDT) {
this.oRDRDT = oRDRDT;
}

@JsonProperty("ORDR_STS")
public String getORDRSTS() {
return oRDRSTS;
}

@JsonProperty("ORDR_STS")
public void setORDRSTS(String oRDRSTS) {
this.oRDRSTS = oRDRSTS;
}

@JsonProperty("SOLD_TO_CUST_ID")
public String getSOLDTOCUSTID() {
return sOLDTOCUSTID;
}

@JsonProperty("SOLD_TO_CUST_ID")
public void setSOLDTOCUSTID(String sOLDTOCUSTID) {
this.sOLDTOCUSTID = sOLDTOCUSTID;
}

@JsonProperty("mtrl")
public List<Mtrl> getMtrl() {
return mtrl;
}

@JsonProperty("mtrl")
public void setMtrl(List<Mtrl> mtrl) {
this.mtrl = mtrl;
}

@Override
public String toString() {
	return "Order [oRDRID=" + oRDRID + ", oRDRSRC=" + oRDRSRC + ", oRDRDC=" + oRDRDC + ", mRKT=" + mRKT + ", oRDRDT="
			+ oRDRDT + ", oRDRSTS=" + oRDRSTS + ", sOLDTOCUSTID=" + sOLDTOCUSTID + ", mtrl=" + mtrl + "]";
}



}