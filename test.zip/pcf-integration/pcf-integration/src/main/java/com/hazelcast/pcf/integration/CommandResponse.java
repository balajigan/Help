package com.hazelcast.pcf.integration;

import com.hazelcast.pcf.integration.model.Order;

@SuppressWarnings("unused")
public class CommandResponse {

    private final String response;
    
    private Order ordResp;

    public CommandResponse(String response) {
        this.response = response;
    }








	public String getResponse() {
        return response;
    }

	public Order getOrdResp() {
		return ordResp;
	}
	
}
